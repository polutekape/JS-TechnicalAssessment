const {PowerType} =  require("./PowerType")

class Vehicle {
    constructor(make, numberOfPassengers, powerType) {
        this.make = make;
        this.numberOfPassengers = numberOfPassengers;
        this.powerType = powerType;
    }
    usesFossilFuel() {
        return (
        this.powerType === PowerType.Petrol || this.powerType === PowerType.Diesel
        );
    }

    getNumberOfPassengers() {
        return this.numberOfPassengers;
    }

    getPowerType() {
        return this.powerType;
    }

    getMake() {
        return this.make;
    }
}
module.exports = {Vehicle}