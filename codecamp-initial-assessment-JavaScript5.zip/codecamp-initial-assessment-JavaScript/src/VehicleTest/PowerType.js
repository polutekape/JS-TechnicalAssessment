const PowerType = {
    Self: 'Self',
    Electricity: 'Electricity',
    Diesel: 'Diesel',
    Petrol: 'Petrol'
};

module.exports = {PowerType}