const {Vehicle} =  require("./Vehicle")
const {Car} =  require("./Car")
const {PowerType} =  require("./PowerType")
const {Bicycle} =  require("./Bicycle")

// Create a collection of vehicles
//static vehicles = [];
const vehicles = [];

// Add instances of different vehicles
vehicles.push(new Car("Holden", 4, PowerType.Petrol));
vehicles.push(new Car("Toyota", 4, PowerType.Petrol));
vehicles.push(new Bicycle("HondaBike", 2, PowerType.Petrol));
vehicles.push(new Bicycle("TeslaBike", 4, PowerType.Electricity));
vehicles.push(new Car("Tesla", 3, PowerType.Electricity));

/*
 *  #1 Create a new Skateboard class which extends Vehicle, then add an instance of it
 *  to the existing vehicles collection
 */



/*
 *  #2 Iterate/Loop over the vehicles and output the name of the first vehicle
 *  which can carry 3 or more passengers and does not use fossil fuel
 */