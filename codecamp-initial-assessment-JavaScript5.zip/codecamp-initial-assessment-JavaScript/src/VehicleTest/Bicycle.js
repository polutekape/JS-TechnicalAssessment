const {Vehicle} =  require("./Vehicle")

class Bicycle extends Vehicle {
    constructor(make, numberOfPassengers, powerType) {
    super(make, numberOfPassengers, powerType);
    }
}

module.exports = {Bicycle}